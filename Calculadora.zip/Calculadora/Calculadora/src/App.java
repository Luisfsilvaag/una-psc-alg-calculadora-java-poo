import java.util.Scanner;

class Calculadora{
public double somar(double a, double b) {
        return a + b;
    }

    public double subtrair(double a, double b) {
        return a - b;
    }

    public double multiplicar(double a, double b) {
        return a * b;
    }

    public double dividir(double a, double b) {
        if (b == 0) {
            System.out.println("Impossível realizar uma divisão por zero.");
            return Double.NaN;
        }
        return a / b;
    }

    public double potencia(double a, double b) {
        return Math.pow(a, b);
    }

    public double raizQuadrada(double a) {
        if (a < 0) {
            System.out.println("Não existe raiz de número negativo.");
            return Double.NaN;
        }
        return Math.sqrt(a);
    }
}

public class App {
public static void main(String[] args) throws Exception {
    Scanner scanner = new Scanner(System.in);
    Calculadora calc = new Calculadora();
    String opcao;

        while (true) {
            System.out.println("Calculadora");
            System.out.println("Escolha a operação:");
            System.out.println("1 Adição");
            System.out.println("2 Subtração");
            System.out.println("3 Multiplicação");
            System.out.println("4 Divisão");
            System.out.println("5 Potência");
            System.out.println("6 Raiz quadrada do primeiro número");
            System.out.println("Q Sair");

            System.out.print("Opção: ");
            opcao = scanner.next();

            if (opcao.equalsIgnoreCase("Q")) {
                System.out.println("Programa encerrado.");
                break;
            }

            double numeroUm, numeroDois = 0, resultado = 0;

            System.out.print("Digite o primeiro número: ");
            numeroUm = scanner.nextDouble();

            if (!opcao.equals("6")) {
                System.out.print("Digite o segundo número: ");
                numeroDois = scanner.nextDouble();
            }

            if (opcao.equals("1")) {
                resultado = calc.somar(numeroUm, numeroDois);
            } else if (opcao.equals("2")) {
                resultado = calc.subtrair(numeroUm, numeroDois);
            } else if (opcao.equals("3")) {
                resultado = calc.multiplicar(numeroUm, numeroDois);
            } else if (opcao.equals("4")) {
                resultado = calc.dividir(numeroUm, numeroDois);
            } else if (opcao.equals("5")) {
                resultado = calc.potencia(numeroUm, numeroDois);
            } else if (opcao.equals("6")) {
                resultado = calc.raizQuadrada(numeroUm);
            } else {
                System.out.println("Opção inválida.");
                continue;
            }

            if (!Double.isNaN(resultado)) {
                System.out.println("Resultado: " + resultado);
            }
        }       
    }
}
